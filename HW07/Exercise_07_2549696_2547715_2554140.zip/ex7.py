import utils
import numpy as np
from math import log10

def single_pmi(term_prob, term_prob_class, use_log=True):
    
    if not use_log:
        if term_prob_class == 0:
            return -float('Inf')
        return log10(term_prob_class / float(term_prob))
    else:
        return term_prob_class - term_prob

def compute_single_category_pmi(pmi_list):
    return max(pmi_list)

def ex4_1():

    # read data
    stop_words = utils.tokenize_text_file("Materials/stopwords.txt")
    train_bio = utils.tokenize_text_file("Materials/train/Biology.txt", stopwords=stop_words)
    train_chem = utils.tokenize_text_file("Materials/train/Chemistry.txt", stopwords=stop_words)
    train_phys = utils.tokenize_text_file("Materials/train/Physics.txt", stopwords=stop_words)

    # preprocess data
    train_bio = utils.lemma_stemming(train_bio) 
    train_chem = utils.lemma_stemming(train_chem)
    train_phys = utils.lemma_stemming(train_phys)

    train_all = train_bio + train_chem + train_phys

    # compute probabilities

    # probabilities of all occurring words in all texts
    p_t = utils.get_probabilities(train_all, train_all, get_log_prob=True)

    # conditional probabilities of all terms depending on class
    p_t_bio = utils.get_probabilities(train_all, train_bio, get_log_prob=True)
    p_t_chem = utils.get_probabilities(train_all, train_chem, get_log_prob=True)
    p_t_phys = utils.get_probabilities(train_all, train_phys, get_log_prob=True)

    bio_pmis = []
    chem_pmis = []
    phys_pmis = []

    all_pmis = [bio_pmis, chem_pmis, phys_pmis]

    # compute pmi values

    for term in set(train_all):

        pmi_bio = single_pmi(p_t[term], p_t_bio[term], use_log=True)
        pmi_chem = single_pmi(p_t[term], p_t_chem[term], use_log=True)
        pmi_phys = single_pmi(p_t[term], p_t_phys[term], use_log=True)

        max_index = np.argmax((pmi_bio, pmi_chem, pmi_phys))

        all_pmis[max_index].append((term, max(pmi_bio, pmi_chem, pmi_phys)))

    return all_pmis




def compute_mi(terms, corpora_list):

    all_corpora = corpora_list[0] + corpora_list[1] + corpora_list[2]

    print("Amount Terms: {}".format(len(set(terms))))
    counter = 0
    # iter over all terms
    for term in set(terms):
        # count occurrences

        print("Current Term: {}/{}".format(counter, len(set(terms))), end="\r", flush=True)
        counter += 1

        # contains frequencies off all corpora
        freq_list = []
        abs_list = []

        for cur_corpus in corpora_list:
            
            d = utils.get_frequence(set(all_corpora), cur_corpus)
            freq_list.append(d)
            abs_list.append(len(cur_corpus))

    max_mi_values = []

    print("Computing MIs")
    for term in set(all_corpora):

        mi_values = []

        for i in [0,1,2]:
            A = freq_list[i][term]
            B = abs_list[i] - A

            # occurence of term in other class
            C = freq_list[(i + 1)%3][term] + freq_list[(i + 2)%3][term]
            D = abs_list[(i + 1)%3] + abs_list[(i + 2)%3] - C

            mi_values.append(utils.get_mutual_information(A, C, B, D))

        max_index = np.argmax(mi_values)
        cats = ["bio", "chem", "phys"]

        max_mi_values.append((term, cats[max_index], mi_values[max_index]))

    # sort after mis
    print("Sorting MIs")
    sorted_list = sorted(max_mi_values, key=lambda x: x[2], reverse=True)
    print("Length sorted: {}".format(len(sorted_list)))

    best_bio = []
    best_chem = []
    best_phys = []

    #print("Splitting Lists")
    for t in sorted_list:
        if t[1] == "bio" and len(best_bio) < 10:
            best_bio.append(t)
        elif t[1] == "chem" and len(best_chem) < 10:
            best_chem.append(t)
        elif t[1] == "phys" and len(best_phys) < 10:
            best_phys.append(t)

        if len(best_bio) + len(best_chem) + len(best_phys) == 30:
            break

    return best_bio, best_chem, best_phys


def ex_4_2():

    # read data
    print("Loading Data")
    stop_words = utils.tokenize_text_file("Materials/stopwords.txt")
    train_bio = utils.tokenize_text_file("Materials/train/Biology.txt", stopwords=stop_words)
    train_chem = utils.tokenize_text_file("Materials/train/Chemistry.txt", stopwords=stop_words)
    train_phys = utils.tokenize_text_file("Materials/train/Physics.txt", stopwords=stop_words)

    # preprocess data
    print("Lemmatizing Data")
    train_bio = utils.lemma_stemming(train_bio) 
    train_chem = utils.lemma_stemming(train_chem)
    train_phys = utils.lemma_stemming(train_phys)

    train_all = train_bio + train_chem + train_phys

    print("Computing MI")
    best_bio, best_chem, best_phys = compute_mi(train_all, [train_bio, train_chem, train_phys])

    print(best_bio)
    print("")
    print(best_chem)
    print("")
    print(best_phys)


if __name__ == "__main__":

    # PMI
    res_lists = ex4_1()

    categories = ["bio", "chem", "phys"]

    for cat_index, pmi_list in enumerate(res_lists):

        print("CATEGORY: {}".format(categories[cat_index]))

        # sort after pmis
        sorted_list = sorted(pmi_list, key=lambda x: x[1], reverse=False)

        for i in range(10):
            term_val = sorted_list[i]
            print("Term: {} - PMI: {}".format(term_val[0], term_val[1])) 

    # Mutual Information
    # ex_4_2()
    

