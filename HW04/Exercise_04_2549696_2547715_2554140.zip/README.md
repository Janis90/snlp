# Homework 1

###Group members:

* Sven Stauden
	* 2549696
	* s9svstau@stud.uni-saarland.de
* Janis Landwehr
	* 2547715
	* s9jaland@stud.uni-saarland.de	 
* Carsten Klaus
	* 2554140 
	* s8caklau@stud.uni-saarland.de

